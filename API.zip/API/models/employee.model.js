let mongoose = require('mongoose');

let employeeSchema = new mongoose.Schema({
    employee_id : String,
    first_name : String,
    last_name : String,
    department : String,
    dob : Date,
    mobile : Number,
    address : String
})

module.exports = mongoose.model('Employee', employeeSchema)