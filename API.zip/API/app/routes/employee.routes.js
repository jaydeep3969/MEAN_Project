module.exports = (app) => {
    const employee = require('../controllers/employee.controller');

    // Create a new Employee
    app.post('/api/employee', employee.create);

    // Retrieve all Employees
    app.get('/api/employee', employee.findAll);

    // Retrieve a single Employee with id
    app.get('/api/employee/:employeeId', employee.findOne);

    // Update an Employee with id
    app.put('/api/employee/:employeeId', employee.update);

    // Delete an Employee with id
    app.delete('/api/employee/:employeeId', employee.delete);
}