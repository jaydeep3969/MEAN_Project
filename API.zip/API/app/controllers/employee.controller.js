const Employee = require('../../models/employee.model');

//Create and Save new Employee
exports.create = (req,res) => {

    //Create an Employee
    let employee = new Employee ({
        employee_id : req.body.employee_id,
        first_name : req.body.first_name,
        last_name : req.body.last_name,
        department : req.body.department,
        dob : req.body.dob,
        mobile : req.body.mobile,
        address : req.body.address
    });

    //Save Employee in DB
    employee.save()
        .then( data => {
            console.log("New employee successfully added !");
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while creating an employee"
            })
        });
};

//Retrieve and return all employees from database
exports.findAll = (req, res) => {
    Employee.find()
        .then( employees => {
            console.log("Employees successfully retrieved !");
            res.send(employees);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while retrieving Employees"
            })            
        });
};

//Find a single employee with an employeeID
exports.findOne = (req,res) => {

    Employee.findById(req.params.employeeId)
        .then( employee => {
            if(!employee)
            {
                return res.status(404).send({
                    message : "Employee not found !"
                })
            }

            console.log("Employee with id successfully retrieved !");
            res.send(employee);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Employee not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving employee with id"
            });
            
        });
};

// Update an employee identified by the employeeId in the request
exports.update = (req, res) => {

    //find employee and update it with the request body
    Employee.findByIdAndUpdate( req.params.employeeId, {
        employee_id : req.body.employee_id,
        first_name : req.body.first_name,
        last_name : req.body.last_name,
        department : req.body.department,
        dob : req.body.dob,
        mobile : req.body.mobile,
        address : req.body.address
    }, {new : true})
        .then(employee => {
            if(!employee) {
                return res.status(404).send({
                    message : "Employee not found with this id !"
                });
            }

            console.log("Employee successfully updated !");
            res.send(employee);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Employee not found with this id !"
                });
            }

            res.status(500).send({
                message : err.message || "Some error occurred while updating the Employee !"
            });
        })
};



// Delete an employee with the specified employeeId in the request
exports.delete = (req, res) => {
    Employee.findByIdAndRemove(req.params.employeeId)
        .then(employee => {
            if(!employee) {
                return res.status(404).send({
                    message : "Employee not found with this id !"
                });
            }

            console.log("Employee successfully deleted !");
            res.send({
                message : "Employee successfully deleted !"
            });
        })
        .catch(err => {
            if(err.kind === 'ObjectId' || err.name === 'NotFound'){
                return res.status(404).send({
                    message : "Employee not found with this id !"
                })
            }

            res.status(500).send({
                message : "Could not delete the Employee with this id !"
            });     
        })
};