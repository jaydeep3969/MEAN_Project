const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');
const cors = require('cors');

var app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended : true }));

require('./app/routes/employee.routes')(app);

app.get('/', (req, res) => {
    res.send("Hello From Node API...");
})

app.listen(3000,  () => {
    console.log("Listening on 3000 ....");
})