export class Employee {
    _id : String;
    employee_id : String;
    first_name : String;
    last_name : String;
    department : String;
    dob : Date;
    mobile : Number;
    address : String
}
